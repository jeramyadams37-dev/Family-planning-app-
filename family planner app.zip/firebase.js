// src/firebase.js

import firebase from "firebase/app";
import "firebase/auth";
import "firebase/firestore";

const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "family-planning-app-d3bd6.firebaseapp.com",
  projectId: "family-planning-app-d3bd6",
  storageBucket: "family-planning-app-d3bd6.appspot.com",
  messagingSenderId: "574163689239",
  appId: "1:574163689239:android:709d6bf338949e27662152",
};

firebase.initializeApp(firebaseConfig);

export const auth = firebase.auth();
export const firestore = firebase.firestore();
