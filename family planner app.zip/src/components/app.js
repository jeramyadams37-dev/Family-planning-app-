// src/components/App.js

import React, { useEffect, useState } from 'react';
import { auth } from '../firebase';
import Chat from './Chat';
import CalendarComponent from './CalendarComponent';
import Login from './Login';
import SignUp from './SignUp';

const App = () => {
  const [user, setUser] = useState(null);
  const [isLoginPage, setIsLoginPage] = useState(true);

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((user) => {
      setUser(user);
    });
    return () => unsubscribe();
  }, []);

  const handleLogin = () => {
    setIsLoginPage(false);
  };

  const handleSignUp = () => {
    setIsLoginPage(false);
  };

  const handleLogout = async () => {
    await auth.signOut();
    setUser(null);
    setIsLoginPage(true);
  };

  return (
    <div>
      <h1>Family Communication App</h1>
      {user ? (
        <div>
          <button onClick={handleLogout}>Logout</button>
          <Chat />
          <CalendarComponent />
        </div>
      ) : (
        isLoginPage ? (
          <Login onLogin={handleLogin} />
        ) : (
          <SignUp onSignUp={handleSignUp} />
        )
      )}
      <button onClick={() => setIsLoginPage(!isLoginPage)}>
        {isLoginPage ? "Switch to Sign Up" : "Switch to Login"}
      </button>
    </div>
  );
};

export default App;
