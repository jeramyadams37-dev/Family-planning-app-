// src/components/CalendarComponent.js

import React, { useState } from 'react';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';

const CalendarComponent = () => {
  const [date, setDate] = useState(new Date());

  const handleDateChange = (date) => {
    setDate(date);
    // Here you can implement logic to create events
  };

  return (
    <div>
      <Calendar onChange={handleDateChange} value={date} />
      <p>Selected Date: {date.toDateString()}</p>
      {/* Additional logic for event creation can be added here */}
    </div>
  );
};

export default CalendarComponent;
